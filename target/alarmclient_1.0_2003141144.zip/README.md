# The module is base on giiwa framework
Please refer http://giiwa.org to learn more about giiwa

# Goal
### Features
* 1) feature1
* 2) feature2

### Start
* Import this project to Eclipse, start to coding.
* run ant in project folder, get the ???_1.0.[buildno].zip.
* uoload the ???_1.0.[buildno].zip in giiwa->Admin->System->Setting->Module->upload.
* After restarted, test your module.
